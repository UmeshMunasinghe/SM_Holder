package com.project.measurement;

public class MeasureObject {
	
	
	double OH;// object height
	double Distance;// distance to object

	
	
	public double DistanceToObject(double Angle01, double MH){
		
		// MH - mobile height
		
		Distance = MH/(Math.tan(Angle01));
		
		return Distance;
		
	}
	
	public double ObjectHeight (double Angle02,double Distance, double MH) {
		
		
		
		OH = ((Math.tan(Angle02))*Distance)+MH;
		
		return OH;
		
	}
	

}
